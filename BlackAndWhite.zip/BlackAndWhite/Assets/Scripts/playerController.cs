﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class playerController : MonoBehaviour {

	public float jumpHeight = 1;
	public float runSpeed = 100;
	public int gravity = 50;
	public float topSpeed = 15;
	public float bulletSpeed = 1;
	public float smackForce = 100;
	public GameObject bulletPrefab;
	public Transform bulletSpawnLeft;
	public Transform bulletSpawnRight;

	private Rigidbody rb;
	private Animator playerAnim;
	private SpriteRenderer playerRenderer;
	private string direction = "right";
	private bool onGround = true;
	private Vector3 moveDirection;
	private float horizontalMovement;
	private Transform bulletSpawn;

	// Use this for initialization
	void Start () {
		rb = GetComponent<Rigidbody>();
		playerAnim = GetComponent<Animator>();
		playerRenderer = GetComponent<SpriteRenderer>();
		playerAnim.Play("whiteStance");
		Physics.gravity = new Vector3(0, -gravity, 0);
		bulletSpawn = bulletSpawnRight;
	}

	void fire() {
		print("fired");
		if (direction == "right") {
			playerRenderer.flipX = false;
		}
		else {
			playerRenderer.flipX = true;
		}
		if (!Input.GetKey(KeyCode.A) && !Input.GetKey(KeyCode.D) && onGround == true) {
			playerAnim.Play("shooting");
		}

		var bullet = (GameObject)Instantiate(
            bulletPrefab,
            bulletSpawn.position,
            bulletSpawn.rotation
        );

        //bullet.GetComponent<Rigidbody>().velocity = (bullet.transform.forward * bulletSpeed);
        if (direction == "right") {
        	bullet.GetComponent<Rigidbody>().AddForce(transform.right * bulletSpeed);
        }
        else {
        	bullet.GetComponent<Rigidbody>().AddForce(-transform.right * bulletSpeed);
        }

        Destroy(bullet, 2.0f);
	}

	void jump() {
		playerAnim.Play("whiteJump");
		Vector3 v = rb.velocity;
		v.y = jumpHeight;
		rb.velocity = v;
		//onGround = false;
	}

	void moveLeft() {
		bulletSpawn = bulletSpawnLeft;
		if (direction == "right") {
			playerRenderer.flipX = true;
			direction = "left";
		}
		else {
			playerRenderer.flipX = true;
		}
		if (onGround == true) {
			playerAnim.Play("whiteRunCycle");
		}
		if (rb.velocity.magnitude < topSpeed) {
			rb.AddForce(-transform.right * runSpeed);
		}
	}

	void moveRight() {
		bulletSpawn = bulletSpawnRight;
		if (direction == "left") {
			playerRenderer.flipX = false;
			direction = "right";
		}
		else {
			playerRenderer.flipX = false;
		}
		if (onGround == true) {
			playerAnim.Play("whiteRunCycle");
		}
		if (rb.velocity.magnitude < topSpeed) {
			rb.AddForce(transform.right * runSpeed);
		}
	}

	void idle() {
		//print(onGround);
		playerAnim.Play("shooting");
		float tmp = rb.velocity.y;
		rb.velocity = new Vector3(0,tmp,0);
	}
	
	// Update is called once per frame
	void FixedUpdate () {
		if (Input.GetKeyDown(KeyCode.Space) && onGround == true) {
			jump();
		}

		if (Input.GetMouseButtonDown(0)) {
			fire();
		}

		/*
		if (Input.GetKey(KeyCode.A) && Input.GetKey(KeyCode.D)) {
			playerRenderer.flipX = false;
			if (rb.velocity.magnitude < topSpeed) {
				rb.AddForce(-transform.right * runSpeed * 0.5f);
			}
		}
		*/

		if (Input.GetKey(KeyCode.A)) {
			moveLeft();
		}

		if (Input.GetKey(KeyCode.D)) {
			moveRight();
		}
		
		if (!Input.GetMouseButtonDown(0) && !Input.GetKey(KeyCode.A) && !Input.GetKey(KeyCode.D) && onGround == true) {
			idle();
		}
		
		//print(rb.velocity.magnitude);
	}

	void OnTriggerEnter(Collider other) {
		if (other.gameObject.CompareTag("ground")){
			onGround = true;
		}
		if (other.gameObject.CompareTag("enemy")) {
			if (direction == "right") {
				rb.AddForce(-transform.right * smackForce);
				//rb.AddForce(transform.up * smackForce*2);
				jump();
			}
			else {
				rb.AddForce(transform.right * smackForce);
				//rb.AddForce(transform.up * smackForce*2);
				jump();
			}
		}
	}

	void OnTriggerExit(Collider other) {
		if (other.gameObject.CompareTag("ground"))
		{
			onGround = false;
		}
	}
}
