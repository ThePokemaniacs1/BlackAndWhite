﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class whiteFace : MonoBehaviour {

	private Animator anim;
	private bool playing = false;

	// Use this for initialization
	void Start () {
		anim = GetComponent<Animator>();
		anim.Play("whiteStill");
	}
	
	// Update is called once per frame
	void Update () {
		if (Input.GetKeyDown(KeyCode.Space)) {
			if (playing == false) {
				anim.Play("whiteTalk");
				playing = true;
			}
			else {
				anim.Play("whiteStill");
				playing = false;
			}
		}
	}
}
