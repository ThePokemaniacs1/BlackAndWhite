﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class redMasqueMovement : MonoBehaviour {

	public float moveSpeed = 1;
	public GameObject temp;

	private Transform leftPos;
	private Transform rightPos;
	private Rigidbody mob;
	private SpriteRenderer mobSprite;
	private Rigidbody[] tmp;
	private SpriteRenderer[] spriteTmp;
	private string direction = "right";
	private redMasqueCollision[] redScript;

	// Use this for initialization
	void Start () {
		leftPos = transform.GetChild(0);
		rightPos = transform.GetChild(1);
		//mob = rigidbody.GetChild(3);
		tmp = GetComponentsInChildren<Rigidbody>();
		//print("tmp length: " + tmp.Length);
		mob = tmp[0];
		spriteTmp = GetComponentsInChildren<SpriteRenderer>();
		mobSprite = spriteTmp[0];
		redScript = gameObject.GetComponentsInChildren<redMasqueCollision>();
	}
	
	// Update is called once per frame
	void Update () {
		if (direction == "right") {
			mob.velocity = transform.right * moveSpeed;
		}
		if (direction == "left") {
			mob.velocity = -transform.right * moveSpeed;
		}

		//print("mob x: " + mob.transform.position.x + ", leftPos x: " + leftPos.position.x);

		if (mob.transform.position.x < leftPos.position.x) {
			direction = "right";
			mobSprite.flipX = false;
		}
		if (mob.transform.position.x > rightPos.position.x) {
			direction = "left";
			mobSprite.flipX = true;
		}

		//print(redScript[0].hit);
		if (redScript[0].hit == true) {
			gameObject.SetActive(false);
		}
	}
}
