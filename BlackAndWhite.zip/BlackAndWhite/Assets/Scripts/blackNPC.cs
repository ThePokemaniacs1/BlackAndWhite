﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class blackNPC : MonoBehaviour {

	private Animator anim;
	private bool playing = false;

	// Use this for initialization
	void Start () {
		anim = GetComponent<Animator>();
		anim.Play("blackStance");
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
